from django.apps import AppConfig


class UsuarioConfig(AppConfig):
    name = 'apps.usuario'
