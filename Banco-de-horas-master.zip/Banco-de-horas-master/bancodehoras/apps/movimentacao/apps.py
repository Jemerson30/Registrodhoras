from django.apps import AppConfig


class MovimentacaoConfig(AppConfig):
    name = 'apps.movimentacao'
